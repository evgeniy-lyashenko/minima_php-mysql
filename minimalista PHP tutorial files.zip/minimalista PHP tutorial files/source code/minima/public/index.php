<?php 
session_start();

require "../app/init.php";

$app = new App();