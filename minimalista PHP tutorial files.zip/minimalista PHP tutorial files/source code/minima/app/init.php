<?php 

require "../app/core/config.php";
require "../app/core/functions.php";
require "../app/core/database.php";
require "../app/core/controller.php";
require "../app/core/app.php";
